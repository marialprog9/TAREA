/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include<iostream>

using namespace std;

int main(){

int n1,n2, suma =0;

cout<< "Digite un numero:"; cin>>n1;
cout<< "Digite un numero:"; cin>>n2;


suma = n1+ n2;


cout<<"\nLa suma es:"<<suma<<endl;

return 0;
}