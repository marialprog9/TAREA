/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>

using namespace std;

int main(){

int n1,n2, multiplicacion=0;

cout<< "Digite un numero:"; cin>>n1;
cout<< "Digite un numero:"; cin>>n2;

multiplicacion = n1*n2;


cout<<"La multiplicacion es:"<<multiplicacion<<endl;

return 0;
}